import os
import datetime
import albumentations as A
import tensorflow as tf
from tensorflow.keras.metrics import AUC, Precision, Recall
from tensorflow.keras import backend as K
from tensorflow.keras.callbacks import TensorBoard, ReduceLROnPlateau, ModelCheckpoint, EarlyStopping
from vit_keras import vit
from tensorflow.keras import mixed_precision

AUTOTUNE = tf.data.AUTOTUNE


class SkinCancerDetector:
    def __init__(self, train_dir, val_dir, test_dir, log_dir='logs', batch_size=64, model_dir='models',
                 img_size=(224, 224)):
        self.train_dir = train_dir
        self.val_dir = val_dir
        self.test_dir = test_dir
        self.log_dir = log_dir
        self.batch_size = batch_size
        self.img_size = img_size
        self.model_dir = model_dir
        self.model = None
        self.precision = Precision()
        self.recall = Recall()
        mixed_precision.set_global_policy('mixed_float16')

    def preprocess_data(self):
        """Preprocess data and apply image augmentation."""
        train_ds = self.create_data_generator(self.train_dir)
        val_ds = self.create_data_generator(self.val_dir)
        test_ds = self.create_data_generator(self.test_dir, augment=False)
        return train_ds, val_ds, test_ds

    def load_and_preprocess_image(self, file_path):
        image = tf.io.read_file(file_path)
        image = tf.image.decode_jpeg(image, channels=3)
        image = tf.image.resize(image, self.img_size)
        image = image / 255.0  # normalize to [0,1] range
        return image

    def augment_image(self, image):
        [image, ] = tf.py_function(self.apply_augmentations, [image], [tf.float32])
        image.set_shape(self.img_size + (3,))
        return image

    def apply_augmentations(self, image):
        transform = A.Compose([
            A.HorizontalFlip(p=0.5),
            A.VerticalFlip(p=0.5),
            # Add other augmentations as needed
        ])
        augmented_img = transform(image=image)['image']
        return augmented_img

    def create_data_generator(self, directory, augment=True):
        list_ds = tf.data.Dataset.list_files(os.path.join(directory, '*/*.jpg'), shuffle=False)
        list_ds = list_ds.shuffle(len(list_ds), reshuffle_each_iteration=False)
        labeled_ds = list_ds.map(self.process_path, num_parallel_calls=AUTOTUNE)
        if augment:
            labeled_ds = labeled_ds.map(lambda img, lbl: (self.augment_image(img), lbl), num_parallel_calls=AUTOTUNE)
        ds = labeled_ds.cache().shuffle(1000).prefetch(buffer_size=AUTOTUNE)
        ds = ds.batch(self.batch_size)
        ds = ds.prefetch(buffer_size=AUTOTUNE)
        return ds

    def process_path(self, file_path):
        label = tf.strings.split(file_path, os.path.sep)[-2]
        image = self.load_and_preprocess_image(file_path)
        return image, label

    def f1_score(self, y_true, y_pred):
        prec = self.precision(y_true, y_pred)
        rec = self.recall(y_true, y_pred)
        return 2 * ((prec * rec) / (prec + rec + K.epsilon()))

    def specificity(self, y_true, y_pred):
        true_negatives = K.sum(K.round(K.clip((1 - y_true) * (1 - y_pred), 0, 1)))
        possible_negatives = K.sum(K.round(K.clip(1 - y_true, 0, 1)))
        return true_negatives / (possible_negatives + K.epsilon())

    def quantize_model(self, model):
        converter = tf.lite.TFLiteConverter.from_keras_model(model)
        converter.optimizations = [tf.lite.Optimize.DEFAULT]
        tflite_quant_model = converter.convert()
        return tflite_quant_model

    def build_model(self, num_classes):
        self.precision = Precision(name='precision')
        self.recall = Recall(name='sensitivity')

        vit_model = vit.vit_b32(
            image_size=self.img_size[0],
            activation='softmax',
            pretrained=True,
            include_top=False,
            pretrained_top=False,
            classes=num_classes)

        self.model = tf.keras.Sequential([
            vit_model,
            tf.keras.layers.Dense(768, activation=tf.nn.relu),
            tf.keras.layers.Dropout(0.25),
            tf.keras.layers.Dense(num_classes, activation='softmax', dtype=tf.float32)
        ])

        self.model.compile(optimizer='adam',
                           loss='categorical_crossentropy',
                           metrics=['accuracy', self.recall, self.precision, self.f1_score, self.specificity,
                                    AUC(name='auc')])

    def train_model(self, train_ds, val_ds, epochs=1000, patience_lr=12, patience_es=40, min_lr=1e-6, min_delta=1e-4,
                    cooldown_lr=5):
        self._check_model()
        current_time = datetime.datetime.now().strftime("%Y%m%d-%H%M%S")
        log_dir = os.path.join(self.log_dir, current_time)
        os.makedirs(log_dir, exist_ok=True)

        callbacks = self._create_callbacks(log_dir, current_time, patience_lr, min_lr, min_delta, patience_es,
                                           cooldown_lr)

        history = self.model.fit(
            train_ds,
            epochs=epochs,
            validation_data=val_ds,
            callbacks=callbacks)
        return history

    def _create_callbacks(self, log_dir, current_time, patience_lr, min_lr, min_delta, patience_es, cooldown_lr):
        tensorboard_callback = TensorBoard(log_dir=log_dir, histogram_freq=1, write_graph=True, write_images=True,
                                           update_freq='epoch', profile_batch=0)
        reduce_lr_callback = ReduceLROnPlateau(monitor='val_loss', factor=0.2, patience=patience_lr, min_lr=min_lr,
                                               min_delta=min_delta, cooldown=cooldown_lr)
        model_checkpoint_callback = ModelCheckpoint(
            filepath=os.path.join(self.model_dir, "{}_best_model.h5".format(current_time)),
            save_best_only=True, monitor='val_loss', mode='min', save_freq='epoch')

        early_stopping_callback = EarlyStopping(monitor='val_loss', min_delta=min_delta, patience=patience_es,
                                                verbose=0, mode='auto', restore_best_weights=True)
        callbacks = [tensorboard_callback, reduce_lr_callback, model_checkpoint_callback, early_stopping_callback]
        return callbacks

    def _check_model(self):
        if self.model is None:
            raise ValueError("Model is not built. Please build the model before training.")

    def evaluate_model(self, test_datagen):
        """Evaluate the model."""
        self._check_model()

        test_generator = test_datagen.flow_from_directory(
            self.test_dir,
            target_size=self.img_size,
            batch_size=self.batch_size,
            class_mode='categorical')

        test_loss, test_acc, test_sensitivity, test_precision, test_f1, test_specificity, test_auc \
            = self.model.evaluate(test_generator)
        print('Test accuracy:', test_acc)
        print('Test sensitivity:', test_sensitivity)
        print('Test precision:', test_precision)
        print('Test F1-score:', test_f1)
        print('Test specificity:', test_specificity)
        print('Test AUC-ROC:', test_auc)
        return test_loss, test_acc, test_sensitivity, test_precision, test_f1, test_specificity, test_auc

    def save_model(self, filename='models/skinvestigator.h5'):
        """Save the model."""
        self._check_model()
        self.model.save(filename)
        self.model = self.quantize_model(self.model)
        with open('models/skinvestigator-quantize.tflite', 'wb') as f:
            f.write(self.model)

    def load_model(self, filename):
        """Load the model."""
        self.model = tf.keras.models.load_model(
            filename,
            custom_objects={
                'f1_score': self.f1_score,
                'specificity': self.specificity
            })
