import os
from skinvestigatorai.core.ai.detector import SkinCancerDetector
from skinvestigatorai.core.ai.config import train_dir, val_dir, test_dir
from skinvestigatorai.core.data_scraper import DataScraper


def get_num_classes(directory):
    return len([d for d in os.listdir(directory) if os.path.isdir(os.path.join(directory, d))])


def main(filename='models/skinvestigator.h5'):
    if not os.path.exists(train_dir):
        print('Downloading data...')
        downloader = DataScraper()
        downloader.download_images(-1)
        print('Done downloading data')

    num_classes = get_num_classes(train_dir)
    print('Detected {} classes'.format(num_classes))

    detector = SkinCancerDetector(train_dir, val_dir, test_dir)
    train_ds, val_ds, test_ds = detector.preprocess_data()
    detector.build_model(num_classes=num_classes)
    detector.train_model(train_ds, val_ds)
    detector.evaluate_model(test_ds)
    detector.save_model(filename)


if __name__ == '__main__':
    main('skin_cancer_detection_model.h5')
