def generate_route_name():
    import uuid
    return str(uuid.uuid4()) + '/train'


