import os
import numpy as np
from PIL import Image
from pyramid.view import view_config
from pyramid.httpexceptions import HTTPBadRequest
from tensorflow.keras.models import load_model
from tensorflow.keras.preprocessing.image import img_to_array
from tensorflow.lite.python.interpreter import Interpreter
from skinvestigatorai.core.ai.detector import SkinCancerDetector

# Load your trained model
model_dir = 'models/'
custom_metrics = {
    'f1_score': SkinCancerDetector.f1_score,
    'specificity': SkinCancerDetector.specificity
}

MODEL_TYPE = 'TFLITE'  # Set this to 'H5' or 'TFLite' as needed


def get_latest_model(model_dir, extension):
    """
    Returns the path of the latest model file in the specified directory with the specified extension.
    """
    list_of_files = [os.path.join(model_dir, basename) for basename in os.listdir(model_dir) if
                     basename.endswith(extension)]
    latest_model = max(list_of_files, key=os.path.getctime)
    return latest_model


def load_model_type(model_type):
    """
    Load the latest model based on the provided model type.
    """
    if model_type.upper() == 'H5':
        model_path = get_latest_model(model_dir, '.h5')
        model = load_model(model_path, custom_objects=custom_metrics)
    elif model_type.upper() == 'TFLITE':
        model_path = get_latest_model(model_dir, '.tflite')
        model = Interpreter(model_path)
    else:
        raise ValueError(f"Unsupported model type {model_type}. Please choose 'H5' or 'TFLite'.")

    return model


model = load_model_type(MODEL_TYPE)
print('Model loaded. Start serving...')

# Define the class labels
class_labels = ['benign', 'malignant', 'unknown']


@view_config(route_name='predict', request_method='POST', renderer='json')
def predict_view(request):
    # Read the image file from the request
    image_file = request.POST['image'].file

    try:
        # Open and preprocess the image
        image = Image.open(image_file).convert('RGB')
        image = image.resize((128, 128))
        image_array = img_to_array(image)
        image_array = image_array / 255.0
        image_array = np.expand_dims(image_array, axis=0)

        # Make a prediction
        if isinstance(model, Interpreter):  # If the model is a TFLite Interpreter
            model.allocate_tensors()
            input_details = model.get_input_details()
            model.set_tensor(input_details[0]['index'], image_array)
            model.invoke()
            output_details = model.get_output_details()
            predictions = model.get_tensor(output_details[0]['index'])
        else:  # If the model is a full Keras model
            predictions = model.predict(image_array)

        # OOD Detection
        max_prob = np.max(predictions)
        threshold = 0.9  # set your threshold here
        if max_prob < threshold:
            predicted_class = 'unknown'
            confidence = max_prob * 100
        else:
            predicted_class = class_labels[np.argmax(predictions)]
            confidence = max_prob * 100

        # Return the prediction result
        return {
            'prediction': predicted_class,
            'confidence': float(confidence),
            'is_in_distribution': predicted_class != 'unknown'
        }
    except Exception as e:
        return HTTPBadRequest(reason=str(e))



@view_config(route_name='dashboard', renderer='skinvestigatorai:templates/dashboard.jinja2')
def dashboard_view(request):
    if 'prediction' in request.session:
        prediction = request.session['prediction']
        confidence = request.session['confidence']
        del request.session['prediction']
        del request.session['confidence']
    else:
        prediction = None
        confidence = None

    return {
        'prediction': prediction,
        'confidence': confidence
    }
