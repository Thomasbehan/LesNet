import os
import logging
from datetime import datetime
from skinvestigatorai.core.ai.detector import SkinCancerDetector
from skinvestigatorai.core.ai.config import train_dir, val_dir, test_dir
from skinvestigatorai.core.data_scraper import DataScraper

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def get_num_classes(directory):
    """Count the number of classes based on the directory structure.
    
    Parameters:
        directory (str): The path to the directory containing the classes.
        
    Returns:
        int: The number of classes.
    """
    return len([d for d in os.listdir(directory) if os.path.isdir(os.path.join(directory, d))])

def train_model(model_filename):
    """Train the skin cancer detection model.
    
    Parameters:
        model_filename (str): The filename for saving the trained model.
    """
    try:
        if not os.path.exists(train_dir):
            logger.info('Downloading data...')
            downloader = DataScraper()
            downloader.download_images(-1)
            logger.info('Done downloading data')

        num_classes = get_num_classes(train_dir)
        logger.info('Detected %d classes', num_classes)

        detector = SkinCancerDetector(train_dir, val_dir, test_dir)
        train_ds, val_ds, test_ds = detector.preprocess_data()
        detector.build_model(num_classes=num_classes)
        detector.train_model(train_ds, val_ds)
        detector.evaluate_model(test_ds)
        detector.save_model(model_filename)
        logger.info('Model trained and saved successfully.')
        
    except Exception as e:
        logger.error('An error occurred during training: %s', e)
        raise

def main():
    """The main entry point of the script."""
    model_filename = 'skin_cancer_detection_model_{}.h5'.format(datetime.now().strftime('%Y%m%d_%H%M%S'))
    train_model(model_filename)

if __name__ == '__main__':
    main()