train_dir = 'data/train'
val_dir = 'data/validation'
test_dir = 'data/test'
